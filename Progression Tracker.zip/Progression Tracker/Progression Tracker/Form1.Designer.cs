﻿namespace Progression_Tracker
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.timeLabel = new System.Windows.Forms.Label();
            this.functionGroupBox = new System.Windows.Forms.GroupBox();
            this.resetButton = new System.Windows.Forms.Button();
            this.startButton = new System.Windows.Forms.Button();
            this.stopButton = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.saveButton = new System.Windows.Forms.Button();
            this.saveTextBox = new System.Windows.Forms.TextBox();
            this.functionGroupBox2 = new System.Windows.Forms.GroupBox();
            this.showFileNamesButton = new System.Windows.Forms.Button();
            this.loadTimeButton = new System.Windows.Forms.Button();
            this.loadTimeTextBox = new System.Windows.Forms.TextBox();
            this.listBox = new System.Windows.Forms.ListBox();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.functionGroupBox.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.functionGroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Location = new System.Drawing.Point(13, 13);
            this.tabControl.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(365, 255);
            this.tabControl.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.saveTextBox);
            this.tabPage1.Controls.Add(this.saveButton);
            this.tabPage1.Controls.Add(this.timeLabel);
            this.tabPage1.Controls.Add(this.functionGroupBox);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Size = new System.Drawing.Size(357, 226);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Timer";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // timeLabel
            // 
            this.timeLabel.AutoSize = true;
            this.timeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timeLabel.Location = new System.Drawing.Point(95, 18);
            this.timeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(163, 69);
            this.timeLabel.TabIndex = 1;
            this.timeLabel.Text = "0:0:0";
            // 
            // functionGroupBox
            // 
            this.functionGroupBox.Controls.Add(this.resetButton);
            this.functionGroupBox.Controls.Add(this.startButton);
            this.functionGroupBox.Controls.Add(this.stopButton);
            this.functionGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.functionGroupBox.Location = new System.Drawing.Point(12, 113);
            this.functionGroupBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.functionGroupBox.Name = "functionGroupBox";
            this.functionGroupBox.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.functionGroupBox.Size = new System.Drawing.Size(337, 58);
            this.functionGroupBox.TabIndex = 0;
            this.functionGroupBox.TabStop = false;
            this.functionGroupBox.Text = "Functions";
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(225, 22);
            this.resetButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(100, 28);
            this.resetButton.TabIndex = 1;
            this.resetButton.Text = "RESET";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(9, 22);
            this.startButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(100, 28);
            this.startButton.TabIndex = 0;
            this.startButton.Text = "START";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // stopButton
            // 
            this.stopButton.Location = new System.Drawing.Point(117, 22);
            this.stopButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.stopButton.Name = "stopButton";
            this.stopButton.Size = new System.Drawing.Size(100, 28);
            this.stopButton.TabIndex = 1;
            this.stopButton.Text = "STOP";
            this.stopButton.UseVisualStyleBackColor = true;
            this.stopButton.Click += new System.EventHandler(this.stopButton_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.listBox);
            this.tabPage2.Controls.Add(this.functionGroupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Size = new System.Drawing.Size(357, 226);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Time Database";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(209, 196);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(128, 23);
            this.saveButton.TabIndex = 2;
            this.saveButton.Text = "Save Time";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // saveTextBox
            // 
            this.saveTextBox.Location = new System.Drawing.Point(21, 196);
            this.saveTextBox.Name = "saveTextBox";
            this.saveTextBox.Size = new System.Drawing.Size(182, 22);
            this.saveTextBox.TabIndex = 3;
            // 
            // functionGroupBox2
            // 
            this.functionGroupBox2.Controls.Add(this.loadTimeTextBox);
            this.functionGroupBox2.Controls.Add(this.loadTimeButton);
            this.functionGroupBox2.Controls.Add(this.showFileNamesButton);
            this.functionGroupBox2.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.functionGroupBox2.Location = new System.Drawing.Point(7, 125);
            this.functionGroupBox2.Name = "functionGroupBox2";
            this.functionGroupBox2.Size = new System.Drawing.Size(343, 94);
            this.functionGroupBox2.TabIndex = 0;
            this.functionGroupBox2.TabStop = false;
            this.functionGroupBox2.Text = "Functions";
            // 
            // showFileNamesButton
            // 
            this.showFileNamesButton.Location = new System.Drawing.Point(6, 21);
            this.showFileNamesButton.Name = "showFileNamesButton";
            this.showFileNamesButton.Size = new System.Drawing.Size(140, 30);
            this.showFileNamesButton.TabIndex = 1;
            this.showFileNamesButton.Text = "Show File Names";
            this.showFileNamesButton.UseVisualStyleBackColor = true;
            this.showFileNamesButton.Click += new System.EventHandler(this.showFileNamesButton_Click);
            // 
            // loadTimeButton
            // 
            this.loadTimeButton.Location = new System.Drawing.Point(6, 57);
            this.loadTimeButton.Name = "loadTimeButton";
            this.loadTimeButton.Size = new System.Drawing.Size(140, 30);
            this.loadTimeButton.TabIndex = 2;
            this.loadTimeButton.Text = "Load Time";
            this.loadTimeButton.UseVisualStyleBackColor = true;
            this.loadTimeButton.Click += new System.EventHandler(this.loadTimeButton_Click);
            // 
            // loadTimeTextBox
            // 
            this.loadTimeTextBox.Location = new System.Drawing.Point(152, 61);
            this.loadTimeTextBox.Name = "loadTimeTextBox";
            this.loadTimeTextBox.Size = new System.Drawing.Size(185, 22);
            this.loadTimeTextBox.TabIndex = 3;
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 16;
            this.listBox.Location = new System.Drawing.Point(13, 7);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(331, 116);
            this.listBox.TabIndex = 1;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(395, 281);
            this.Controls.Add(this.tabControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "MainForm";
            this.Text = "Progression Tracker";
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.functionGroupBox.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.functionGroupBox2.ResumeLayout(false);
            this.functionGroupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.GroupBox functionGroupBox;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Button stopButton;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox saveTextBox;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.GroupBox functionGroupBox2;
        private System.Windows.Forms.Button showFileNamesButton;
        private System.Windows.Forms.TextBox loadTimeTextBox;
        private System.Windows.Forms.Button loadTimeButton;
        private System.Windows.Forms.ListBox listBox;
    }
}

