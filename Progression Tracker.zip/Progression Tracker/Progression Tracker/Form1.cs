﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Progression_Tracker
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            CreateFileForFileNames();

        }

        private int hr = 0;
        private int min = 0;
        private int sec = 0;
        private int ms = 0;

        private int count = 0;
        private string savedTime;

        public void CreateFileForFileNames()
        {
            TextWriter sw = new StreamWriter("File Names.txt", true);
            sw.Close();
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            // if the user loaded a saved time from a file,
            // and wants to continue with the time left,
            // then don't start with the consequence of reseting the time to 0
            // but continue off from the selected time
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timeLabel.Text = hr + ":" + min + ":" + sec.ToString();
            sec++;
            if (sec > 59)
            {
                min++;
                sec = 0;
            }
            else if (min > 59)
            {
                hr++;
                sec = 0;
                min = 0;
            }
        }

        private void stopButton_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            ms = 0;
            sec = 0;
            min = 0;
            hr = 0;
            timeLabel.Text = "0:0:0";
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            string fileName = saveTextBox.Text;
            fileName += ".txt";
            using (StreamWriter sw = new StreamWriter(fileName))
            {
                sw.WriteLine(hr + ":" + min + ":" + --sec);
            }

            using (TextWriter sw = new StreamWriter("File Names.txt", true))
            {
                sw.WriteLine(fileName);
            }

            MessageBox.Show("Saved!");
        }

        private void showFileNamesButton_Click(object sender, EventArgs e)
        {
            // read the content of the File Names.txt file
            // into a list
            var logFile = File.ReadAllLines("File Names.txt");
            var logList = new List<string>(logFile);
            // get rid of duplicate file names
            List<string> distinct = logList.Distinct().ToList();

            // the fileNameList list should now have the name of the files
            var message = string.Join(Environment.NewLine, distinct);
            MessageBox.Show(message);
        }

        private void loadTimeButton_Click(object sender, EventArgs e)
        {
            // get the name of the file with the saved time from the user's last point of timing
            string fileName = loadTimeTextBox.Text;
            fileName += ".txt";

            // open the file
            using (StreamReader sr = new StreamReader(fileName))
            {
                savedTime = sr.ReadLine();
            }

            // load or update the time in the timer's tab with the savedTime variable
            timeLabel.Text = savedTime;

            string[] hourMinuteSecond = savedTime.Split(':');
            int hour = Convert.ToInt32(hourMinuteSecond[0]);
            int minute = Convert.ToInt32(hourMinuteSecond[1]);
            int second = Convert.ToInt32(hourMinuteSecond[2]);

            hr = hour;
            min = minute;
            sec = second;

            MessageBox.Show("Loaded Time! Check Timer Tab");

        }
    }
}
